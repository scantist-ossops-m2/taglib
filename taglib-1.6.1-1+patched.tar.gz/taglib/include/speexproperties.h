#include "../taglib/ogg/speex/speexproperties.h"
