#include "../taglib/riff/wav/wavproperties.h"
