#include "../taglib/mpeg/id3v2/frames/attachedpictureframe.h"
